
#pragma once


using namespace std;



constexpr int main_loop_target_frame_us = 33333; // 30


const int SCREEN_IMAGE_ROWS = 280;
const int SCREEN_IMAGE_COLS = 1024;

const int SCULPTURE_IMAGE_ROWS = 70;
const int SCULPTURE_IMAGE_COLS = 256;




enum Player_Param_Index
{
  GAIN = 0,
  BLACK_LEVEL = 1,
  COLOR_GAIN = 2,
  COLOR_HUE = 3,
  IMAGE_GAMMA = 4,
  H_SHIFT = 5,
  SPEED = 6,
  FILTER_TYPE = 7,
  PAUSE_TOGGLE = 8,
  FAST_FORWARD = 9,
  REWIND = 10,
  H_ROTATE = 11  
};

  enum Default_Limits_Index
  {
    DEFAULT = 0,
    LOWER_LIMIT = 1,
    UPPER_LIMIT = 2,
  };









