#include "kv_io.h"
#include "sculpture.h"
#include "measure2.h"
#include "globals.h"
#include "image_processor.h"
#include "fs_utils.h"

#include <chrono>
#include <thread>
#include <algorithm> // for std::clamp

using Clock = std::chrono::steady_clock;
using namespace kvio;

Sculpture::Sculpture() = default;

Sculpture::Sculpture(const std::string &filename, const std::string &tag)
{
    VP[0].Open_Image_File_Mat(filename, tag);
    VP[1].Open_Image_File_Mat(filename, tag);
    // image_mixed_ will be sized lazily in Cross_Fade based on A/B

    Read_2D_Number(Sample_Points_Map, "Day_For_Night_Sample_Map.csv");

    // Read_2D_Number(Sample_Points_Map, "test1.csv");

    // // Read_2D_Number(Sculpture_Map, "Day_For_Night_Sample_Map.csv");

    // for (int i = 0; i < Sample_Points_Map.size(); i++)
    // {
    //     for (int j = 0; j < Sample_Points_Map[i].size(); j++)
    //         std::cout << Sample_Points_Map[i][j] << " ";
    //     std::cout << std::endl;
    // }

    // Read_2D_Number(Sample_Points_Map, "test2.csv");

    // std::cout << std::endl;
    // std::cout << std::endl;

    // // Read_2D_Number(Sculpture_Map, "Day_For_Night_Sample_Map.csv");

    // for (int i = 0; i < Sample_Points_Map.size(); i++)
    // {
    //     for (int j = 0; j < Sample_Points_Map[i].size(); j++)
    //         std::cout << Sample_Points_Map[i][j] << " ";
    //     std::cout << std::endl;
    // }

    // exit(0);

    Mixer_Params = Mixer_Params_Defaults;
}

const cv::Mat &Sculpture::Cross_Fade(const cv::Mat &A, const cv::Mat &B, bool toA, float fade_length_sec)
{
    CV_Assert(A.size() == B.size() && A.type() == B.type());

    // ensure buffer shape/type
    image_mixed_.create(A.size(), A.type());

    // advance fade toward target
    constexpr float kAssumedFps = 30.0f; // or compute dt with steady_clock for frame-rate independence
    const float step = (fade_length_sec > 0.f) ? (1.0f / (fade_length_sec * kAssumedFps)) : 1.0f;

    fade_level_ += toA ? +step : -step;
    fade_level_ = std::clamp(fade_level_, 0.0f, 1.0f);

    cv::addWeighted(A, fade_level_, B, 1.0f - fade_level_, 0.0, image_mixed_);
    return image_mixed_;
}

void Sculpture::Advance(std::array<cv::Mat, 4> &outputs)
{
    static bool direc = true;

    check_and_load_new_kv_from_gui_dual(GUI_Player_Names, VP[0].Player_Params, VP[1].Player_Params);

    auto process_start = Clock::now();

    // VP[0].Process_New_Frame_Ext_Process();
    // VP[1].Process_New_Frame_Ext_Process();
    // thread the 2 players
    std::jthread t1([&]
                    { VP[0].Process_New_Frame_Ext_Process(); });
    std::jthread t2([&]
                    { VP[1].Process_New_Frame_Ext_Process(); });
    t1.join();
    t2.join(); // ⬅️ ensure both finished

    Cross_Faded_F = Cross_Fade(VP[0].ImageMain_FM, VP[1].ImageMain_FM, direc, 5);

    // for display
    Cross_Faded_F.convertTo(Cross_Faded_M, CV_8UC3);

    auto process2_start = Clock::now();
    Save_Samples_Grid_To_Buffer_RGB(Cross_Faded_F, Cross_Faded_F_Sampled);

    // temp sampler
    // resize(Cross_Faded_F, Cross_Faded_F_Sampled, cv::Size(), 0.25, 0.25, cv::INTER_NEAREST);
    auto process2_delta = GetDeltaTime(process2_start);

    // sub sample

    // map

    // send to ftdi driver

    Mixer_Params[H_SHIFT] = 100;
    Cross_Faded_F_Sampled = process_image_with_shift(Cross_Faded_F_Sampled, Mixer_Params);

    // for display
    Cross_Faded_F_Sampled.convertTo(Cross_Faded_M_Sampled, CV_8UC3);

    outputs[0] = VP[0].VideoDisplay; // shallow copy
    outputs[1] = VP[1].VideoDisplay; // shallow copy

    outputs[2] = Cross_Faded_M;
    outputs[3] = Cross_Faded_M_Sampled;

    auto process_delta = GetDeltaTime(process_start);

    if ((loop_counter++) % 30 == 0)
        cout << "process_delta  " << process_delta << "     process2_delta " << process2_delta << endl;

    if ((loop_counter % 180) == 0)
        direc = !direc;
}

// RGB float in -> RGB float out (both CV_32FC3)
// simplified: no stagger

void Sculpture::Save_Samples_Grid_To_Buffer_RGB(
    const cv::Mat &ImageIn_F,   // CV_32FC3, source
    cv::Mat &ImageSubSampled_F, // CV_32FC3, SCULPTURE_IMAGE_ROWS x SCULPTURE_IMAGE_COLS
    bool auto_gap,
    int H_gap, // used if !auto_gap (pixels)
    int V_gap) // used if !auto_gap (pixels)
{
    CV_Assert(ImageIn_F.type() == CV_32FC3);

    const int src_rows = ImageIn_F.rows;
    const int src_cols = ImageIn_F.cols;

    // Compute sampling gaps in source space
    const float h_gap = auto_gap
                            ? float(src_cols) / float(SCULPTURE_IMAGE_COLS)
                            : float(H_gap);

    const float v_gap = auto_gap
                            ? float(src_rows) / float(SCULPTURE_IMAGE_ROWS)
                            : float(V_gap);

    // Allocate/reuse output
    ImageSubSampled_F.create(SCULPTURE_IMAGE_ROWS, SCULPTURE_IMAGE_COLS, CV_32FC3);

    // Centered sampling
    float row_f = v_gap * 0.5f;

    for (int row_out = 0; row_out < SCULPTURE_IMAGE_ROWS; ++row_out)
    {
        const int row_in = int(row_f + 0.5f); // guaranteed in-range by your contract

        const cv::Vec3f *src_row = ImageIn_F.ptr<cv::Vec3f>(row_in);
        cv::Vec3f *dst_row = ImageSubSampled_F.ptr<cv::Vec3f>(row_out);

        float col_f = h_gap * 0.5f;

        for (int col_out = 0; col_out < SCULPTURE_IMAGE_COLS; ++col_out)
        {
            const int col_in = int(col_f + 0.5f); // guaranteed in-range
            dst_row[col_out] = src_row[col_in];
            col_f += h_gap;
        }
        row_f += v_gap;
    }
}
