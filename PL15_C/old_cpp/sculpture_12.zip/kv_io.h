#pragma once
#include <string>
#include <utility>
#include <vector>
#include <cstdint>
#include "player_class_Mat.h"

namespace kvio
{

    // Start the TCP server (bind/listen). Returns true on success.
    bool start_server(const std::string &host, std::uint16_t port);

    // Poll the socket(s) once and return ALL complete key/value pairs
    // currently available. Both key and value are strings (transport-agnostic).
    std::vector<std::pair<std::string, std::string>> poll_kv();

} // namespace kvio

namespace kvio
{
    bool send_kv(const std::string &key, const std::string &val);
}

namespace kvio
{
    bool check_and_load_new_kv_from_gui(Video_Player_With_Processing &VP_In, const std::vector<std::string> &names,
                                        std::vector<int> &params);
}

namespace kvio
{
bool check_and_load_new_kv_from_gui_dual(const std::vector<std::string> &names, vector<int> &Player_Params0, vector<int> &Player_Params1);
}


namespace kvio
{
    int init_gui(std::string host = "127.0.0.1", uint16_t port = 5000);
    bool start_server(const std::string &host, uint16_t port);
}

extern const std::vector<std::string> GUI_Player_Names;
